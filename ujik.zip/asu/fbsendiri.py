import base64
decode ="ZmI="
data =base64.b64decode(decode)
print data
